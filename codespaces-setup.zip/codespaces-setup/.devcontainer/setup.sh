#!/bin/bash
set -e

echo "============================================"
echo "🚀 Full Stack Auto-Fix Environment Setup"
echo "============================================"

# ---------------------------------------------
# 1. Claude Code CLI
# ---------------------------------------------
echo ""
echo "📦 Installing Claude Code CLI..."
npm install -g @anthropic-ai/claude-code
echo "✅ Claude Code CLI installed"

# ---------------------------------------------
# 2. Vercel CLI
# ---------------------------------------------
echo ""
echo "📦 Installing Vercel CLI..."
npm install -g vercel
echo "✅ Vercel CLI installed"

# ---------------------------------------------
# 3. Railway CLI
# ---------------------------------------------
echo ""
echo "📦 Installing Railway CLI..."
npm install -g @railway/cli
echo "✅ Railway CLI installed"

# ---------------------------------------------
# 4. EAS CLI (Expo)
# ---------------------------------------------
echo ""
echo "📦 Installing EAS CLI..."
npm install -g eas-cli
echo "✅ EAS CLI installed"

# ---------------------------------------------
# 5. その他便利ツール
# ---------------------------------------------
echo ""
echo "📦 Installing additional tools..."
npm install -g typescript ts-node nodemon
echo "✅ Additional tools installed"

# ---------------------------------------------
# 6. 確認
# ---------------------------------------------
echo ""
echo "============================================"
echo "✅ All installations complete!"
echo "============================================"
echo ""
echo "Installed versions:"
echo "-------------------------------------------"
echo "gh:       $(gh --version | head -n 1)"
echo "node:     $(node --version)"
echo "npm:      $(npm --version)"
echo "claude:   $(claude --version 2>/dev/null || echo 'Run: claude login')"
echo "vercel:   $(vercel --version)"
echo "railway:  $(railway --version)"
echo "eas:      $(eas --version)"
echo "-------------------------------------------"
echo ""
echo "⚠️  Next steps:"
echo "   1. claude login     (Claude Max認証)"
echo "   2. vercel login     (Vercel認証)"
echo "   3. railway login    (Railway認証)"
echo "   4. eas login        (EAS認証)"
echo ""
