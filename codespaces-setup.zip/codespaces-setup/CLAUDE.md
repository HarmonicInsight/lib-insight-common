# プロジェクト設定

## ビルドエラー自動修正

「ビルドエラー直して」「エラー直して」と言われたら:

### 1. 全環境チェック
```bash
./scripts/auto-fix.sh
```

### 2. 個別環境チェック

#### GitHub Actions
```bash
gh run list --status failure --limit 1
gh run view <RUN_ID> --log-failed
```

#### Vercel
```bash
vercel list
vercel logs <DEPLOYMENT_URL>
```

#### Railway
```bash
railway logs
```

#### EAS (Expo)
```bash
eas build:list --status=errored --limit=1
eas build:view <BUILD_ID>
```

### 3. 修正フロー
1. エラーログ取得
2. ファイルを直接編集して修正
3. `git add -A && git commit -m "fix: エラー内容" && git push`

## ローカルビルド

| 環境 | コマンド |
|------|----------|
| Node.js | `npm run build` |
| TypeScript | `npx tsc --noEmit` |
| テスト | `npm test` |
| Lint | `npm run lint` |

## 修正ルール
- TypeScript: anyは使わず適切な型を定義
- import: 相対パスは ./から始める
- 未使用変数は削除
- console.logは本番コードから削除

## 認証コマンド
```bash
claude login      # Claude Code
gh auth login     # GitHub
vercel login      # Vercel
railway login     # Railway
eas login         # EAS
```
