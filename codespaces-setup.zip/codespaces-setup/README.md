# Codespaces Auto-Fix Environment

GitHub Codespaces上でClaude Code CLIを使ったビルドエラー自動修正環境。

## 🚀 クイックスタート

### 1. このファイルを自分のリポジトリにコピー

```
your-repo/
├── .devcontainer/
│   ├── devcontainer.json
│   └── setup.sh
├── scripts/
│   └── auto-fix.sh
└── CLAUDE.md
```

### 2. Codespacesを起動

1. GitHubでリポジトリを開く
2. `Code` → `Codespaces` → `Create codespace on main`
3. 自動的にセットアップが実行される（2-3分）

### 3. 各サービスにログイン

```bash
# Claude (必須)
claude login

# GitHub (通常は自動認証済み)
gh auth status

# Vercel (使う場合)
vercel login

# Railway (使う場合)
railway login

# EAS (使う場合)
eas login
```

### 4. 使う

```bash
# 方法1: スクリプト実行
./scripts/auto-fix.sh

# 方法2: Claude Codeに直接指示
claude "ビルドエラー直して"

# 方法3: 特定の環境だけ
claude "GitHub Actionsのエラーを修正して"
```

---

## 📦 インストールされるツール

| ツール | 用途 |
|--------|------|
| Claude Code CLI | AI自動修正 |
| gh (GitHub CLI) | GitHub操作 |
| vercel | Vercelデプロイ |
| railway | Railwayデプロイ |
| eas | Expo/RNビルド |
| typescript | 型チェック |
| nodemon | 開発サーバー |

---

## 🔧 対応環境

| 環境 | 自動修正 | 備考 |
|------|----------|------|
| GitHub Actions | ✅ | フル対応 |
| Vercel | ✅ | フル対応 |
| Railway | ✅ | フル対応 |
| EAS (Expo) | ✅ | フル対応 |
| ローカルビルド | ✅ | npm run build |
| iOS Native | ❌ | Mac必須 |

---

## 📝 使用例

### 全環境一括チェック

```bash
./scripts/auto-fix.sh
```

### GitHub Actionsエラーだけ修正

```bash
claude "gh run list で失敗を確認して、エラーを修正してpushして"
```

### Vercelエラーだけ修正

```bash
claude "vercel listで最新デプロイを確認して、エラーがあれば修正して"
```

### ローカルビルドを修正

```bash
claude "npm run build を実行して、エラーがあれば修正して"
```

---

## ⚙️ カスタマイズ

### ビルドコマンドを変更

`CLAUDE.md` を編集:

```markdown
## ローカルビルド
| 環境 | コマンド |
|------|----------|
| ビルド | `yarn build` |      # npm → yarn に変更
| テスト | `yarn test` |
```

### 新しい環境を追加

`scripts/auto-fix.sh` に関数を追加:

```bash
check_your_service() {
    # エラーチェックロジック
}
```

---

## 💰 コスト

| サービス | 費用 |
|----------|------|
| GitHub Codespaces | 無料枠60時間/月 |
| Claude Max | $100-200/月（既存契約内） |

**追加API費用なし**

---

## ❓ トラブルシューティング

### claude コマンドが動かない
```bash
claude login
```

### gh コマンドが動かない
```bash
gh auth login
```

### Codespaces が遅い
Machine type を 4-core に変更

---

## 📄 ライセンス

MIT
