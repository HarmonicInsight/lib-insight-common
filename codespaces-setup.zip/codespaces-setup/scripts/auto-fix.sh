#!/bin/bash
# ============================================
# 全環境ビルドエラー自動修正スクリプト
# ============================================

MAX_ATTEMPTS=5
REPO="${GITHUB_REPOSITORY:-$(gh repo view --json nameWithOwner -q .nameWithOwner 2>/dev/null)}"

echo "============================================"
echo "🔧 Auto-Fix Build Errors"
echo "   Repository: $REPO"
echo "============================================"

# ---------------------------------------------
# 1. GitHub Actions チェック
# ---------------------------------------------
check_github_actions() {
    echo ""
    echo "📋 Checking GitHub Actions..."
    
    RUN_ID=$(gh run list --status failure --limit 1 --json databaseId -q '.[0].databaseId' 2>/dev/null)
    
    if [ -z "$RUN_ID" ]; then
        echo "   ✅ No failed runs"
        return 0
    fi
    
    echo "   ❌ Failed run detected: #$RUN_ID"
    ERROR_LOG=$(gh run view $RUN_ID --log-failed 2>/dev/null | tail -100)
    
    echo "   🔄 Fixing with Claude Code..."
    claude -p "GitHub Actionsのビルドエラーを修正してください。ファイルを直接編集してください。

エラーログ:
$ERROR_LOG"
    
    return 1
}

# ---------------------------------------------
# 2. Vercel チェック
# ---------------------------------------------
check_vercel() {
    echo ""
    echo "📋 Checking Vercel..."
    
    if ! command -v vercel &> /dev/null; then
        echo "   ⏭️  Vercel CLI not configured, skipping"
        return 0
    fi
    
    # 最新デプロイの状態確認
    DEPLOY_STATUS=$(vercel list --json 2>/dev/null | head -1 | jq -r '.[0].state' 2>/dev/null)
    
    if [ "$DEPLOY_STATUS" != "ERROR" ]; then
        echo "   ✅ No failed deployments"
        return 0
    fi
    
    DEPLOY_URL=$(vercel list --json 2>/dev/null | head -1 | jq -r '.[0].url' 2>/dev/null)
    echo "   ❌ Failed deployment: $DEPLOY_URL"
    
    ERROR_LOG=$(vercel logs $DEPLOY_URL 2>/dev/null | tail -50)
    
    echo "   🔄 Fixing with Claude Code..."
    claude -p "Vercelのビルドエラーを修正してください。ファイルを直接編集してください。

エラーログ:
$ERROR_LOG"
    
    return 1
}

# ---------------------------------------------
# 3. Railway チェック
# ---------------------------------------------
check_railway() {
    echo ""
    echo "📋 Checking Railway..."
    
    if ! command -v railway &> /dev/null; then
        echo "   ⏭️  Railway CLI not configured, skipping"
        return 0
    fi
    
    # Railway ログ取得（エラーがあれば）
    ERROR_LOG=$(railway logs 2>/dev/null | grep -i "error" | tail -30)
    
    if [ -z "$ERROR_LOG" ]; then
        echo "   ✅ No errors detected"
        return 0
    fi
    
    echo "   ❌ Errors found in Railway logs"
    echo "   🔄 Fixing with Claude Code..."
    
    claude -p "Railwayのビルドエラーを修正してください。ファイルを直接編集してください。

エラーログ:
$ERROR_LOG"
    
    return 1
}

# ---------------------------------------------
# 4. EAS (Expo) チェック
# ---------------------------------------------
check_eas() {
    echo ""
    echo "📋 Checking EAS (Expo)..."
    
    if ! command -v eas &> /dev/null; then
        echo "   ⏭️  EAS CLI not configured, skipping"
        return 0
    fi
    
    BUILD_ID=$(eas build:list --status=errored --limit=1 --json 2>/dev/null | jq -r '.[0].id' 2>/dev/null)
    
    if [ -z "$BUILD_ID" ] || [ "$BUILD_ID" == "null" ]; then
        echo "   ✅ No failed builds"
        return 0
    fi
    
    echo "   ❌ Failed EAS build: $BUILD_ID"
    ERROR_LOG=$(eas build:view $BUILD_ID --json 2>/dev/null | jq -r '.message // .error // "Unknown error"')
    
    echo "   🔄 Fixing with Claude Code..."
    claude -p "EAS (Expo)のビルドエラーを修正してください。ファイルを直接編集してください。

Build ID: $BUILD_ID
エラー:
$ERROR_LOG"
    
    return 1
}

# ---------------------------------------------
# 5. ローカルビルド チェック
# ---------------------------------------------
check_local_build() {
    echo ""
    echo "📋 Checking local build..."
    
    if [ -f "package.json" ]; then
        BUILD_OUTPUT=$(npm run build 2>&1)
        if [ $? -eq 0 ]; then
            echo "   ✅ Local build successful"
            return 0
        fi
        
        echo "   ❌ Local build failed"
        echo "   🔄 Fixing with Claude Code..."
        
        claude -p "ローカルビルドエラーを修正してください。ファイルを直接編集してください。

エラー:
$BUILD_OUTPUT"
        
        return 1
    fi
    
    echo "   ⏭️  No package.json found, skipping"
    return 0
}

# ---------------------------------------------
# メイン処理
# ---------------------------------------------
FIXED=0

for attempt in $(seq 1 $MAX_ATTEMPTS); do
    echo ""
    echo "============================================"
    echo "🔄 Attempt $attempt / $MAX_ATTEMPTS"
    echo "============================================"
    
    ERRORS=0
    
    check_github_actions || ERRORS=$((ERRORS + 1))
    check_vercel || ERRORS=$((ERRORS + 1))
    check_railway || ERRORS=$((ERRORS + 1))
    check_eas || ERRORS=$((ERRORS + 1))
    check_local_build || ERRORS=$((ERRORS + 1))
    
    if [ $ERRORS -eq 0 ]; then
        echo ""
        echo "============================================"
        echo "✅ All checks passed!"
        echo "============================================"
        FIXED=1
        break
    fi
    
    echo ""
    echo "🔄 Errors found and fixes applied. Retrying..."
    sleep 3
done

# ---------------------------------------------
# 結果とコミット
# ---------------------------------------------
if [ $FIXED -eq 1 ]; then
    # 変更があればコミット
    if ! git diff --quiet 2>/dev/null; then
        echo ""
        echo "📝 Committing fixes..."
        git add -A
        git commit -m "fix: auto-fix build errors"
        git push
        echo "✅ Fixes pushed!"
    fi
else
    echo ""
    echo "============================================"
    echo "⚠️  Could not fix all errors after $MAX_ATTEMPTS attempts"
    echo "============================================"
    exit 1
fi
