#!/bin/bash
# シンプル版: Claude Codeに全部任せる
claude "全てのビルド環境(GitHub Actions, Vercel, Railway, EAS, ローカル)をチェックして、エラーがあれば修正してgit pushしてください"
